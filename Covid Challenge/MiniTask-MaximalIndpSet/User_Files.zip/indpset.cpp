#include <vector>
#include <iostream>
#include <cmath>
#include "indpset.h"
using namespace std;

const int N=101*1000;

int n,m;
vector <pair<int,int> > e[N];

vector <int> rem;
bool terminated;

int current_node;

vector <pair<int,long long> > msgs[N];
vector <pair<int,pair<int,long long> > > new_msgs;

vector <int> ans;

long long get_rnd()
{
	return rand()%1000;
}

void pick_node()
{
	if(terminated)return ;
	ans.push_back(current_node);
}

void terminate_node()
{
	terminated=true;
}

void send_msg(int recipient_pos,long long msg)
{
	if(terminated)return ;
	int recipient,current_node_pos;
	if(recipient_pos==-1)
	{
		recipient=current_node;
		current_node_pos=-1;
	}
	else
	{
		recipient=e[current_node][recipient_pos].first;
		current_node_pos=e[current_node][recipient_pos].second;
	}
	new_msgs.push_back({recipient,{current_node_pos,msg}});
}


void run_program(){
	srand(79);
	cin>>n>>m;
	for(int i=0;i<m;i++)
	{
		int v,u;
		cin>>v>>u;
		e[v].push_back({u,(int)e[u].size()});
		e[u].push_back({v,(int)e[v].size()-1});
	}
	for(int i=1;i<=n;i++)rem.push_back(i);
	int max_turns=2*ceil(log2(n));
	int turn=0;
	while(rem.size())
	{
		turn++;
		if(turn>max_turns)
		{
			cout<<"0\n";
			return ;
		}
		vector <int> new_rem;
		for(auto v:rem)
		{
			current_node=v;
			terminated=false;
			process(e[current_node].size(),msgs[current_node],turn);
			msgs[current_node].clear();
			
			if(!terminated)new_rem.push_back(v);
		}
		rem.swap(new_rem);
		for(auto msg:new_msgs)
			msgs[msg.first].push_back(msg.second);
		new_msgs.clear();
	}
	cerr<<turn<<"\n";
	cout<<ans.size()<<"\n";
	for(auto v:ans)cout<<v<<" ";
	return ;
}
