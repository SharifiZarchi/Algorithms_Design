#include <vector>
#include "indpset.h"
using namespace std;

void process(int neighbors_cnt,vector <pair<int,long long> > msgs,int turn)
{
	
}

int main()
{
	run_program();
	return 0;
}





