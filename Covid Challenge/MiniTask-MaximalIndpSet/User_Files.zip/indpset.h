#ifndef INDPSET_H
#define INDPSET_H
#include <vector>

void run_program();
long long get_rnd();
void pick_node();
void terminate_node();
void send_msg(int,long long);

void process(int,std::vector<std::pair<int,long long> >,int);

#endif

